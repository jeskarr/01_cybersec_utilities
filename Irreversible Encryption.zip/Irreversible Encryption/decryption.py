import string
import base64

ALPHABET = list(string.printable)   # len = 100
LEN = len(ALPHABET)

#from the encryption code we recover this important function
def XORencode(message, KEY="c4mPar1"):
    rep = len(message)//len(KEY) + 1
    key = (KEY*rep)[:len(message)] # adjust the key len
    xored = ''.join([chr(ord(a) ^ ord(b)) for a,b in zip(message, key)])
    return xored

def XORdecode(cipher):
    #property of xor: a ^ b + c -> c ^ b + a
    #So let's imagine a it's the message before being xored, b is the key (that we have for deafult) and c is the xored message (that we have)
    return XORencode(cipher)


#from a string encoded in hexadecimal return a unicode string
def hex2ascii(hexStr):
    decList = []        #declist is a list which elements are integers (each integer represent a char)
    for i in range(len(hexStr) // 2):         
        hexchar = hexStr[i*2 : (i+1)*2]     #each hex char is formed by 2 simbols
        decList.append(int(hexchar, base=16))      #transform to decimal each hex char
    
    UniStr = ""
    for elem in decList:
        UniStr += chr(elem)
    return UniStr

#from a string encoded in base64 return a unicode string
def base64decode(enc_text):
    #b64edcode() accept as parameter a b64 encoded string which is a byte like object
    dec_bytes = base64.b64decode(enc_text.encode('ascii', errors="ignore"))
    
    #transform byte string into normal unicode string
    text = dec_bytes.decode('ascii', errors="ignore")

    return text


#same as b64decode
def base32decode(enc_text):
    dec_bytes = base64.b32decode(enc_text.encode('ascii', errors="ignore"))
    text = dec_bytes.decode('ascii', errors="ignore")
    return text


#shift each char of the message backwards as much as given by pos
def ROTdecode(enc_text, pos):
    dec_text = ""
    for c in enc_text:
        i = ALPHABET.index(c)
        dec_text += ALPHABET[(i-pos)%LEN]
    return dec_text




def main():
    #read the file
    with open("encrypted_flag.txt", "r") as f:
        enc_text = f.read()

    #proceding to reverse the encryption algorithm by:
    
    dec_text = hex2ascii(enc_text)  #hex -> ascii
    dec_text = XORencode(dec_text)  #undo the XOR

    for _ in range(15):     #as for the encryption we repeat these algorithms 15 times
        dec_text = ROTdecode(dec_text, 3)       #reverse the ROT encryption (with pos = 3)
        dec_text = base32decode(dec_text)       #reverse the base32 encoding
        dec_text = ROTdecode(dec_text, 13)      #reverse the ROT encryption (with pos = 13)
        dec_text = base64decode(dec_text)       #reverse the base64 encoding
    
    print("The decrypted message is: ", dec_text)


if __name__ == "__main__":
    main()