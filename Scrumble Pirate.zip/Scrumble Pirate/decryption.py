#Given an encrypted text and a dict encrypted_char : decrypted_char it decrypt the ciphertext
def substitute(cipher, alphabet):
    for k, v in alphabet.items():
        cipher = cipher.replace(k, v)
    return cipher


def main():

    #read the file
    with open("challenge.txt", "r") as file:
        cipher = ''.join(file.readlines())

    #let's define a dictionary containing the encrypted letters as key and the decrypted ones as corrispondent value
    sub_alphabet = {}

    #Cryptanalysis

    #In the last line: DMPXST{ZEOWPHST_R_VEROY_SAL_EOL_MXLZL!} -> spritz{...}
    sub_alphabet["D"] = "s"
    sub_alphabet["M"] = "p"
    sub_alphabet["P"] = "r"
    sub_alphabet["X"] = "i"
    sub_alphabet["S"] = "t"
    sub_alphabet["T"] = "z"

    #cipher = substitute(cipher, sub_alphabet)
    #print(cipher)

    #second line: "tE" can onmly be "to"
    #a very common word in the text is "tAL", so most probably it stands for "the"

    sub_alphabet["E"] = "o"
    sub_alphabet["A"] = "h"
    sub_alphabet["L"] = "e"

    #cipher = substitute(cipher, sub_alphabet)
    #print(cipher)

    #in the flag we can se "oOe_pieZe" which is most likely "one_piece"
    sub_alphabet["O"] = "n"
    sub_alphabet["Z"] = "c"

    #7th line:  oRt to the seH on H -> out on the sea on a
    sub_alphabet["R"] = "u"
    sub_alphabet["H"] = "a"

    #cipher = substitute(cipher, sub_alphabet)
    #print(cipher)

    #flag in the last line is: spritz{conWratz_u_VounY_the_one_piece!}  -> spritz{congratz_u_found_the_one_piece!}
    sub_alphabet["W"] = "g"
    sub_alphabet["V"] = "f"
    sub_alphabet["Y"] = "d"

    #cipher = substitute(cipher, sub_alphabet)
    #print(cipher)

    sub_alphabet["C"] = "w"     #first line: "Cealth", "poCer" -> "wealth", "power"
    sub_alphabet["Q"] = "k"     #second line: "spoQe" -> "spoke"
    sub_alphabet["N"] = "y"     #third line: "Nou(r)"" -> "you(r)""
    sub_alphabet["U"] = "l"     #third line: "Ueft"    -> "left"
    sub_alphabet["K"] = "m"     #third line: "Ky"    -> "my"
    sub_alphabet["G"] = "j"     #7th line: "Gourney" -> "journey"
    sub_alphabet["F"] = "b"     #7th line: "Fecome" -> "become"
    sub_alphabet["B"] = "v"     #second line: "droBe" -> "drove"

    plaintext = substitute(cipher, sub_alphabet)
    print("The decrypted text is:\n", plaintext)

    #We found the flag: it's "spritz{congratz_u_found_the_one_piece!}"
    print("The flag is: spritz{congratz_u_found_the_one_piece!}")


if __name__ == "__main__":
    main()